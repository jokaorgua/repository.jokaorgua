Seasonvar.RU
============

Kodi media plugin for http://www.seasonvar.ru

Installation
============

1. Get an api key by purchasing a subscribtion. Check http://seasonvar.ru/?mod=api for the key
2. Enter the key into 'Setting->API Key' input field
3. Next you need to activate IP address for your device. To do that, try to use plugin by navigating into 'Latest shows' category. Request will be made and you may be able to activate your ip on 'seasonvar' website.
4. That's it, get some beer and enjoy!